import BackgroundVideo from './components/layout/BackgroundVideo';
import WorkingArea from './components/layout/WorkingArea';
import Navbar from './components/layout/Navbar';
import CustomCursor from './features/cursor/CustomCursor';
import HeroSection from './components/sections/Hero/HeroSection';
import PhilosophySection from './components/sections/Philosophy/PhilosophySection';
import ArchiveSection from './components/sections/Archive/ArchiveSection';
import ConnectSection from './components/sections/Connect/ConnectSection';
import Marquee from './components/common/Marquee';

export default function App() {
  return (
    <div className="relative min-h-screen bg-black/10">
      <BackgroundVideo />
      <Navbar />
      <CustomCursor />
      <WorkingArea>
        <HeroSection />
        <PhilosophySection />
        <Marquee />
        <ArchiveSection />
        <ConnectSection />
      </WorkingArea>
    </div>
  );
}
