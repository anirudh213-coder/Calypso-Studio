import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { references, services } from '../../data/content';

export default function Marquee() {
  const topTrackRef = useRef<HTMLDivElement>(null);
  const bottomTrackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const topTrack = topTrackRef.current;
    const bottomTrack = bottomTrackRef.current;
    if (!topTrack || !bottomTrack) return;

    const ctx = gsap.context(() => {
      const topContent = topTrack.innerHTML;
      const bottomContent = bottomTrack.innerHTML;
      topTrack.innerHTML = topContent + topContent;
      bottomTrack.innerHTML = bottomContent + bottomContent;

      const topWidth = topTrack.scrollWidth / 2;
      const bottomWidth = bottomTrack.scrollWidth / 2;

      gsap.to(topTrack, {
        x: -topWidth,
        duration: 30,
        ease: 'none',
        repeat: -1,
      });

      gsap.fromTo(
        bottomTrack,
        { x: -bottomWidth },
        { x: 0, duration: 85, ease: 'none', repeat: -1 },
      );
    });

    return () => ctx.revert();
  }, []);

  return (
    <div
      className="relative overflow-hidden border-y border-black/10"
      aria-label="Calypso services and selected references"
    >
      <div className="overflow-hidden border-b border-black/10 bg-white py-4 md:py-5">
        <div ref={topTrackRef} className="flex w-max items-center whitespace-nowrap">
          {services.map((service, index) => (
            <div key={`${service}-${index}`} className="flex items-center">
              <span className="px-6 text-[clamp(1.5rem,3vw,3.5rem)] leading-none tracking-[-0.05em] text-black md:px-10">
                {service}
              </span>
              <span className="text-[10px] text-black/45 md:text-xs" aria-hidden="true">
                ✦
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="overflow-hidden bg-[#ebe9e9] py-4 md:py-5">
        <div ref={bottomTrackRef} className="flex w-max items-center whitespace-nowrap">
          {references.map((reference, index) => (
            <div key={`${reference.name}-${index}`} className="group flex items-center">
              <span className="flex min-w-[160px] items-center justify-center px-8 md:min-w-[210px] md:px-12">
                <img
                  src={reference.src}
                  alt={reference.name}
                  className="h-8 w-auto max-w-[160px] object-contain opacity-70 grayscale transition-all duration-500 group-hover:scale-[1.05] group-hover:opacity-100 md:h-10 md:max-w-[190px]"
                />
              </span>
              <span className="text-[10px] text-black/20 md:text-xs" aria-hidden="true">
                ✦
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
