import { useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollToPlugin } from 'gsap/ScrollToPlugin';
import { navItems } from '../../data/content';

gsap.registerPlugin(ScrollToPlugin);

export default function Navbar() {
  const [active, setActive] = useState('home');

  useEffect(() => {
    const sections = navItems.map(({ id }) => document.getElementById(id)).filter(Boolean) as HTMLElement[];
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: '-35% 0px -55% 0px', threshold: [0, 0.25, 0.5, 0.75, 1] },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const go = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    gsap.to(window, { duration: 1.25, scrollTo: { y: el, offsetY: 0 }, ease: 'power4.inOut' });
  };

  return (
    <nav className="group fixed right-0 top-1/2 z-[999] -translate-y-1/2" aria-label="Primary">
      <div className="relative w-16 overflow-hidden rounded-l-3xl border border-r-0 border-white/10 bg-black/[0.24] backdrop-blur-xl shadow-[-12px_0_45px_rgba(255,255,255,0.10)] transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:w-[400px]">
        <div className="pointer-events-none absolute right-0 top-1/2 z-20 flex -translate-y-1/2 flex-col items-center gap-3 opacity-100 transition-all duration-500 group-hover:translate-x-10 group-hover:opacity-0">
          <span className="h-2 w-2 rounded-full bg-white shadow-[0_0_16px_rgba(255,255,255,0.75)]" />
          <span className="h-8 w-px bg-white/30" />
          <span className="font-mono-ui mr-3 text-[18px] font-medium uppercase tracking-[0.98em] text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.15)] [writing-mode:vertical-rl]">CALYPSO MENU</span>
        </div>

        <div className="flex min-h-[620px] w-[400px] translate-x-8 flex-col justify-center px-10 py-10 opacity-0 transition-all duration-500 ease-out group-hover:translate-x-0 group-hover:opacity-100">
          <div className="flex flex-col gap-10">
            {navItems.map((item, index) => {
              const isActive = active === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => go(item.id)}
                  data-cursor="interactive"
                  className={`group/link relative flex items-center gap-4 rounded-xl px-5 py-4 text-left font-mono-ui text-base uppercase tracking-[0.24em] transition-all duration-300 hover:bg-[#F4A261]/[0.10] md:text-lg ${isActive ? 'text-white' : 'text-white/40 hover:text-white'}`}
                >
                  <span className={`h-2 w-2 shrink-0 rounded-full bg-white transition-all duration-300 ${isActive ? 'scale-100 opacity-100 shadow-[0_0_14px_rgba(255,255,255,0.65)]' : 'scale-50 opacity-0 group-hover/link:scale-100 group-hover/link:opacity-60'}`} />
                  <span className="relative">{item.label}</span>
                  <span className="pointer-events-none absolute -inset-x-4 -inset-y-2 -z-10 rounded-2xl bg-white/[0.08] opacity-0 blur-2xl transition-opacity duration-500 group-hover/link:opacity-100" />
                  <span className="ml-auto text-[9px] tracking-[0.15em] text-white/20">0{index + 1}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
