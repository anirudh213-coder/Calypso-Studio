import type { projects } from '../../../data/content';

type Project = (typeof projects)[number];

export default function ArchiveProjectInfo({ project, refProp }: { project: Project; refProp: React.RefObject<HTMLDivElement | null> }) {
  return (
    <div ref={refProp} className="archive-project-info pointer-events-none absolute bottom-8 left-5 z-20 text-left md:bottom-10 md:left-8">
      <div className="mb-3 font-mono-ui text-[9px] uppercase tracking-[.2em] text-white/50">{project.year}</div>
      <h3 className="text-[clamp(2.5rem,5vw,5.5rem)] leading-none tracking-[-0.06em]">{project.title}</h3>
      <div className="mt-3 font-mono-ui text-[9px] uppercase tracking-[.2em] text-white/50">{project.category}</div>
      <div className="mt-6 font-mono-ui text-[8px] uppercase tracking-[.25em] text-white/35">Click video For Next project</div>
    </div>
  );
}
