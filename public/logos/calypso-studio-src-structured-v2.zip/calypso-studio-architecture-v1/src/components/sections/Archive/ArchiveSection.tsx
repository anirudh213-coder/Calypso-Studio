import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { projects } from '../../../data/content';
import ArchiveProjectInfo from './ArchiveProjectInfo';

gsap.registerPlugin(ScrollTrigger);

export default function ArchiveSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const projectInfoRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const activeProject = projects[activeIndex];

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', once: true } });
      tl.from('.archive-label', { y: 20, opacity: 0, duration: 0.8, ease: 'power4.out' })
        .from('.archive-title', { y: 100, opacity: 0, duration: 1.2, ease: 'power4.out' }, '-=0.5')
        .from('.archive-project-info', { y: 40, opacity: 0, duration: 0.8, ease: 'power4.out' }, '-=0.6');
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const changeProject = () => {
    const nextIndex = (activeIndex + 1) % projects.length;
    const video = videoRef.current;
    const info = projectInfoRef.current;
    if (!video || !info) { setActiveIndex(nextIndex); return; }
    gsap.timeline({ onComplete: () => setActiveIndex(nextIndex) })
      .to(video, { opacity: 0, scale: 1.05, duration: 0.45, ease: 'power3.inOut' }, 0)
      .to(info, { opacity: 0, y: 20, duration: 0.3, ease: 'power3.in' }, 0);
  };

  useEffect(() => {
    const video = videoRef.current;
    const info = projectInfoRef.current;
    if (!video || !info) return;
    video.load();
    const playVideo = () => { video.currentTime = 0; void video.play().catch(() => {}); };
    if (video.readyState >= 2) playVideo();
    else video.addEventListener('loadeddata', playVideo, { once: true });
    gsap.fromTo(video, { opacity: 0, scale: 1.05 }, { opacity: 1, scale: 1, duration: 0.8, ease: 'power4.out' });
    gsap.fromTo(info, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.65, ease: 'power4.out' });
    return () => video.removeEventListener('loadeddata', playVideo);
  }, [activeIndex]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); changeProject(); }
  };

  return (
    <section id="archive" ref={sectionRef} className="relative min-h-screen overflow-hidden bg-black text-white md:mt-4">
      <div data-cursor="camera" className="absolute inset-0 z-0 cursor-none" onClick={changeProject} onKeyDown={handleKeyDown} role="button" tabIndex={0} aria-label={`Change selected project. Current project: ${activeProject.title}`}>
        <video ref={videoRef} key={activeProject.video} src={activeProject.video} className="h-full w-full object-cover" autoPlay muted loop playsInline preload="metadata" />
        <div className="pointer-events-none absolute inset-0 bg-black/25" />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-black/20" />
      </div>
      <div className="pointer-events-none absolute left-5 top-8 z-20 md:left-8 md:top-10">
        <h2 className="archive-title mt-4 text-[clamp(4rem,8vw,8rem)] font-medium leading-[0.82] tracking-[-0.07em]">Selected<br />work</h2>
      </div>
      <ArchiveProjectInfo project={activeProject} refProp={projectInfoRef} />
    </section>
  );
}
