import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { InstagramIcon, LinkedinIcon, LocationIcon, MailIcon, PhoneIcon } from '../../ui/Icon';
import ContactLink from './ContactLink';
import StudioMap from './StudioMap';

gsap.registerPlugin(ScrollTrigger);

export default function ConnectSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ scrollTrigger: { trigger: sectionRef.current, start: 'top 80%', once: true } });
      tl.from('.connect-index', { y: 20, opacity: 0, duration: 0.7, ease: 'power3.out' })
        .from('.connect-map', { y: 45, opacity: 0, scale: 0.97, duration: 1, ease: 'power4.out' }, '-=0.35')
        .from('.connect-main', { y: 45, opacity: 0, duration: 0.9, ease: 'power4.out' }, '-=0.7')
        .from('.connect-contact', { y: 20, opacity: 0, stagger: 0.08, duration: 0.6, ease: 'power3.out' }, '-=0.4')
        .from('.connect-footer', { y: 15, opacity: 0, duration: 0.6, ease: 'power3.out' }, '-=0.35');
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section id="connect" ref={sectionRef} className="relative overflow-hidden border-t border-white/15 px-5 py-10 md:px-8 md:py-14">
      <div className="connect-index flex items-center justify-between font-mono-ui text-[9px] uppercase tracking-[.3em] text-white/45">
        <span className="hidden md:block">Independent digital studio</span>
      </div>

      <div className="mt-12 grid gap-10 md:mt-16 md:grid-cols-12 md:gap-8">
        <div className="connect-map md:col-span-7"><StudioMap /></div>

        <div className="connect-main md:col-span-5">
          <p className="mb-6 font-mono-ui text-[9px] uppercase tracking-[.25em] text-white/40">Have an ambitious idea?</p>
          <a href="mailto:hello@calypso.studio" data-cursor="interactive" className="group block overflow-hidden">
            <div className="text-[clamp(3rem,5vw,6rem)] leading-[.78] tracking-[-.075em]">
              <span className="inline-block transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:-translate-y-[0.025em]">HELLO@</span>
              <span className="font-serif-display inline-block transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)] group-hover:italic">CALYPSO</span>
              <span className="inline-block transition-transform duration-700 ease-[cubic-bezier(.22,1,.36,1)]">.STUDIO</span>
            </div>
          </a>

          <div className="mt-12">
            <div className="connect-contact"><ContactLink label="Email" value="hello@calypso.studio" href="mailto:hello@calypso.studio" icon={<MailIcon />} /></div>
            <div className="connect-contact"><ContactLink label="Phone" value="+91 00000 00000" href="tel:+910000000000" icon={<PhoneIcon />} /></div>
            <div className="connect-contact"><ContactLink label="Studio" value="Bangalore, India" href="https://www.google.com/maps/search/?api=1&query=Bangalore%2C%20India" icon={<LocationIcon />} /></div>
            <div className="connect-contact"><ContactLink label="Instagram" value="@calypso.studio" href="#" icon={<InstagramIcon />} /></div>
            <div className="connect-contact"><ContactLink label="LinkedIn" value="Calypso Studio" href="#" icon={<LinkedinIcon />} /></div>
          </div>
        </div>
      </div>

      <div className="connect-footer mt-12 grid gap-3 border-t border-white/10 pt-5 font-mono-ui text-[9px] uppercase tracking-[.2em] text-white/35 md:mt-16 md:grid-cols-3">
        <span>© 2026 Calypso</span>
        <span className="md:text-center">India / Worldwide</span>
        <span className="md:text-right">Built by <a href="https://github.com/anirudh213-coder" target="_blank" rel="noreferrer" className="text-white/50 transition-colors duration-300 hover:text-white">Anirudh Makwana</a></span>
      </div>
    </section>
  );
}
