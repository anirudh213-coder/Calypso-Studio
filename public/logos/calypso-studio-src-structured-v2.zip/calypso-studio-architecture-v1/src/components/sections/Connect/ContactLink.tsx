import type { ReactNode } from 'react';
import { useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowIcon } from '../../ui/Icon';

interface ContactLinkProps {
  label: string;
  value: string;
  href: string;
  icon: ReactNode;
}

export default function ContactLink({ label, value, href, icon }: ContactLinkProps) {
  const iconRef = useRef<HTMLSpanElement>(null);
  const valueRef = useRef<HTMLSpanElement>(null);

  const handleEnter = () => {
    if (!iconRef.current || !valueRef.current) return;
    gsap.to(iconRef.current, { scale: 1.2, x: 5, y: -5, rotation: -7, duration: 0.45, ease: 'power3.out' });
    gsap.to(valueRef.current, { x: 8, duration: 0.45, ease: 'power3.out' });
  };

  const handleLeave = () => {
    if (!iconRef.current || !valueRef.current) return;
    gsap.to(iconRef.current, { scale: 1, x: 0, y: 0, rotation: 0, duration: 0.7, ease: 'elastic.out(1, 0.45)' });
    gsap.to(valueRef.current, { x: 0, duration: 0.6, ease: 'power3.out' });
  };

  return (
    <a href={href} className="group flex items-center justify-between border-t border-white/10 py-5" onMouseEnter={handleEnter} onMouseLeave={handleLeave}>
      <div className="flex items-center gap-5">
        <span ref={iconRef} className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white/45 transition-colors duration-300 group-hover:border-white/30 group-hover:text-white">{icon}</span>
        <div>
          <span className="block font-mono-ui text-[8px] uppercase tracking-[.22em] text-white/30">{label}</span>
          <span ref={valueRef} className="mt-2 block text-lg tracking-[-.025em] transition-opacity duration-300 group-hover:opacity-70">{value}</span>
        </div>
      </div>
      <span className="text-white/25 transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-white/70"><ArrowIcon /></span>
    </a>
  );
}
