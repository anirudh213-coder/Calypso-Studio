import { ArrowIcon } from '../../ui/Icon';

export default function StudioMap() {
  return (
    <div data-cursor="pin" className="group relative aspect-[16/10] cursor-none overflow-hidden border border-white/10 bg-[#111]">
      <iframe
        title="Calypso studio location"
        src="https://www.google.com/maps?q=Bangalore%2C%20India&z=12&output=embed"
        className="pointer-events-none absolute inset-0 h-full w-full border-0 grayscale invert opacity-55 transition-all duration-1000 group-hover:opacity-75"
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      />
      <div className="pointer-events-none absolute inset-0 bg-black/10" />
      <div className="absolute left-4 top-4 font-mono-ui text-[8px] tracking-[.2em] text-white/55">12.9716° N</div>
      <div className="absolute right-4 top-4 font-mono-ui text-[8px] tracking-[.2em] text-white/35">77.5946° E</div>
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <span className="absolute -inset-6 animate-ping rounded-full border border-white/20" />
        <div className="relative flex h-8 w-8 items-center justify-center rounded-full border border-white/60 bg-black/60 backdrop-blur-sm"><div className="h-1.5 w-1.5 rounded-full bg-white" /></div>
      </div>
      <div className="absolute bottom-4 left-4">
        <div className="font-mono-ui text-[8px] uppercase tracking-[.2em] text-white/30">Studio location</div>
        <div className="mt-1 text-lg tracking-[-.03em]">Bangalore, India</div>
      </div>
      <a href="https://www.google.com/maps/search/?api=1&query=Bangalore%2C%20India" target="_blank" rel="noreferrer" className="group absolute bottom-4 right-4 flex items-center gap-3 font-mono-ui text-[8px] uppercase tracking-[.2em] text-white/50 transition-colors hover:text-white">
        Open maps
        <span className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"><ArrowIcon /></span>
      </a>
    </div>
  );
}
