import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Logo } from '../../common/Logo';
import HeroSubtitle from './HeroSubtitle';
import HeroTitle from './HeroTitle';
import UnicodeRain from './UnicodeRain';

export default function HeroSection() {
  const heroRef = useRef<HTMLDivElement>(null);
  const logoRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const lettersRef = useRef<HTMLDivElement>(null);
  const devanagariRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const subtitleChars = subtitleRef.current?.querySelectorAll('.subtitle-char');
      const letters = lettersRef.current?.querySelectorAll('.hero-letter');
      const psO = lettersRef.current?.querySelectorAll('.typing-letter');
      if (!subtitleChars || !letters || !psO) return;

      gsap.set(logoRef.current, { x: -120, opacity: 0 });
      gsap.set(subtitleChars, { opacity: 0, y: 8 });
      gsap.set(letters, { opacity: 0 });
      gsap.set('.letter-C', { x: -100 });
      gsap.set('.letter-A', { y: 100 });
      gsap.set('.letter-L', { x: -100 });
      gsap.set('.letter-Y', { y: 100 });
      gsap.set(psO, { opacity: 0, y: 50 });

      const timeline = gsap.timeline();
      timeline.to(logoRef.current, { x: 0, opacity: 1, duration: 0.8, ease: 'power4.out' });
      timeline.to(subtitleChars, { opacity: 1, y: 0, duration: 0.01, stagger: 0.02, ease: 'none' });
      timeline.to('.letter-C', { x: 0, opacity: 1, duration: 0.6, ease: 'power4.out' });
      timeline.to('.letter-A', { y: 0, opacity: 1, duration: 0.6, ease: 'power4.out' }, '-=0.45');
      timeline.to('.letter-L', { x: 0, opacity: 1, duration: 0.6, ease: 'power4.out' }, '-=0.45');
      timeline.to('.letter-Y', { y: 0, opacity: 1, duration: 0.6, ease: 'power4.out' }, '-=0.45');
      timeline.to(psO, { opacity: 1, y: 0, duration: 0.22, stagger: 0.3, ease: 'power2.out' });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={heroRef} id="home" className="relative min-h-screen overflow-hidden px-5 pb-10 pt-6 md:px-8 md:pt-8">
      <div className="relative z-10 min-h-[calc(100vh-2rem)]">
        <div className="relative z-20 flex min-h-[calc(100vh-2rem)] w-full flex-col justify-between pr-0 md:w-[72%] md:pr-8">
          <div className="flex flex-col">
            <div ref={logoRef} className="w-fit -translate-y-4 md:-translate-y-6">
              <Logo className="h-auto w-64 text-white md:w-[30rem]" />
            </div>
            <HeroSubtitle refProp={subtitleRef} />
          </div>
          <HeroTitle refProp={lettersRef} />
        </div>
        <UnicodeRain refProp={devanagariRef} />
      </div>
    </section>
  );
}
