import type { RefObject } from 'react';
import { subtitleLines } from '../../../data/content';

export default function HeroSubtitle({ refProp }: { refProp: RefObject<HTMLDivElement | null> }) {
  return (
    <div
      ref={refProp}
      className="mt-16 flex flex-col gap-1 font-mono-ui text-[11px] uppercase leading-[1.35] tracking-[0.2em] text-white italic md:mt-20 md:text-xl"
      aria-label={`${subtitleLines[0]} ${subtitleLines[1]}`}
    >
      {subtitleLines.map((line, lineIndex) => (
        <div key={line} className="flex flex-wrap">
          {line.split('').map((char, index) => (
            <span key={`${lineIndex}-${char}-${index}`} className="subtitle-char whitespace-pre">
              {char}
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}
