import type { RefObject } from 'react';
import { heroLetters } from '../../../data/content';

export default function HeroTitle({ refProp }: { refProp: RefObject<HTMLDivElement | null> }) {
  return (
    <div ref={refProp}>
      <div className="flex items-end">
        {heroLetters.slice(0, 4).map((letter, index) => (
          <span
            key={`${letter.char}-${index}`}
            className={[
              'hero-letter inline-block text-[19vw] font-semibold leading-[0.80] tracking-[-0.09em] text-[#F4A261] md:text-[16vw]',
              index === 0 ? 'letter-C' : '',
              index === 1 ? 'letter-A' : '',
              index === 2 ? 'letter-L' : '',
              index === 3 ? 'letter-Y' : '',
            ].join(' ')}
          >
            {letter.char}
          </span>
        ))}

        {heroLetters.slice(4).map((letter, index) => (
          <span
            key={`${letter.char}-${index + 4}`}
            className={[
              'typing-letter relative mx-[0.01em] inline-block italic text-[19vw] font-semibold leading-[0.80] tracking-[-0.09em] text-white md:text-[16vw]',
              'drop-shadow-[0_0_8px_rgba(255,255,255,0.55)]',
              'drop-shadow-[0_0_24px_rgba(255,255,255,0.22)]',
            ].join(' ')}
          >
            {letter.char}
          </span>
        ))}
      </div>

      <div className="mt-10 border-t border-white/15 pt-4">
        <p className="max-w-md text-md leading-relaxed text-white/65 underline">
          We build identities, digital spaces and visual systems for brands that refuse to look ordinary.
        </p>
      </div>
    </div>
  );
}
