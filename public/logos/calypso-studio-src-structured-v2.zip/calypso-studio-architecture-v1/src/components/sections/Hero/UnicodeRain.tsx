import type { RefObject } from 'react';
import { useEffect } from 'react';
import { gsap } from 'gsap';
import { unicodeRanges } from '../../../data/content';

function isUsableGlyph(char: string) {
  return (
    !/\p{M}/u.test(char) &&
    !/\p{P}/u.test(char) &&
    !/\p{S}/u.test(char) &&
    !/\p{C}/u.test(char) &&
    !/\p{Z}/u.test(char)
  );
}

function buildScriptPools() {
  const pools: Record<string, string[]> = {};
  for (const range of unicodeRanges) {
    const pool: string[] = [];
    for (let codePoint = range.start; codePoint <= range.end; codePoint++) {
      try {
        const char = String.fromCodePoint(codePoint);
        if (isUsableGlyph(char)) pool.push(char);
      } catch {
        // Ignore invalid Unicode code points.
      }
    }
    if (pool.length > 0) pools[range.name] = pool;
  }
  return pools;
}

const scriptPools = buildScriptPools();
const scriptNames = Object.keys(scriptPools);

function getRandomGlyph() {
  const randomScript = scriptNames[Math.floor(Math.random() * scriptNames.length)];
  const pool = scriptPools[randomScript];
  return pool[Math.floor(Math.random() * pool.length)];
}

function generateUnicodeColumn(length = 180) {
  return Array.from({ length }, () => getRandomGlyph());
}

const languageColumns = Array.from({ length: 14 }, () => generateUnicodeColumn(180));

export default function UnicodeRain({ refProp }: { refProp: RefObject<HTMLDivElement | null> }) {
  useEffect(() => {
    if (!refProp.current) return;

    const tracks = refProp.current.querySelectorAll('.devanagari-track');
    const animations: gsap.core.Tween[] = [];

    tracks.forEach((track, index) => {
      const direction = index % 2 === 0 ? 1 : -1;
      const singleCopyHeight = (track as HTMLElement).scrollHeight / 2;
      const duration = direction === 1 ? 45 + (index % 5) * 90 : 38 + (index % 4) * 90;
      const startY = direction === 1 ? -singleCopyHeight : 0;
      const endY = direction === 1 ? 0 : -singleCopyHeight;

      animations.push(
        gsap.fromTo(
          track,
          { y: startY },
          { y: endY, duration, ease: 'none', repeat: -1, repeatDelay: 0 },
        ),
      );
    });

    return () => animations.forEach((animation) => animation.kill());
  }, [refProp]);

  return (
    <div
      ref={refProp}
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-10 hidden overflow-hidden select-none md:block"
      style={{
        maskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.35) 5%, black 13%, black 87%, rgba(0,0,0,0.35) 95%, transparent 100%)',
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, rgba(0,0,0,0.35) 5%, black 13%, black 87%, rgba(0,0,0,0.35) 95%, transparent 100%)',
      }}
    >
      <div className="absolute right-[-1%] top-0 flex h-full w-[57%] justify-between gap-x-5 px-1 md:gap-x-7">
        {languageColumns.map((column, index) => {
          const repeatedColumn = [...column, ...column];
          return (
            <div key={index} className="relative h-full w-[22px] overflow-hidden opacity-35 md:w-[28px]">
              <div className="devanagari-track absolute left-1/2 flex -translate-x-1/2 flex-col items-center will-change-transform">
                {repeatedColumn.map((glyph, glyphIndex) => (
                  <span key={`${glyph}-${glyphIndex}`} className="block h-[29px] w-[24px] select-none text-center font-serif text-[11px] font-normal leading-[29px] tracking-normal text-[#F4A261]/100 md:h-[33px] md:w-[28px] md:text-[23px] md:leading-[33px]">
                    {glyph}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
