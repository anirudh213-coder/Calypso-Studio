import { philosophyImages } from '../../../data/content';

export default function PhilosophyBackground({ refProp }: { refProp: React.RefObject<HTMLDivElement | null> }) {
  return (
    <div ref={refProp} aria-hidden="true" className="pointer-events-none absolute inset-x-0 -top-[22%] -bottom-[22%] z-0 overflow-hidden">
      <div className="absolute inset-0 flex gap-[2px]">
        {philosophyImages.map((image, index) => (
          <div key={`${image}-${index}`} className="relative h-full min-w-0 flex-1 overflow-hidden">
            <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-black/45" />
            {index === 1 && <div className="absolute inset-0 bg-[#F3B39D]/10 mix-blend-screen" />}
          </div>
        ))}
      </div>
      <div className="absolute inset-0 bg-black/20" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,transparent_0%,rgba(0,0,0,.72)_88%)]" />
    </div>
  );
}
