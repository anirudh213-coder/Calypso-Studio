import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { philosophyLines } from '../../../data/content';
import PhilosophyBackground from './PhilosophyBackground';

gsap.registerPlugin(ScrollTrigger);

export default function PhilosophySection() {
  const ref = useRef<HTMLElement>(null);
  const parallaxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(parallaxRef.current, { yPercent: -18 }, {
        yPercent: 18,
        ease: 'none',
        scrollTrigger: { trigger: ref.current, start: 'top bottom', end: 'bottom top', scrub: 1.2 },
      });

      gsap.from('.ph-line', {
        y: 80,
        opacity: 0,
        duration: 1,
        stagger: 0.12,
        ease: 'power4.out',
        scrollTrigger: { trigger: ref.current, start: 'top 72%', once: true },
      });
    }, ref);

    return () => ctx.revert();
  }, []);

  return (
    <section id="philosophy" ref={ref} className="relative mb-4 min-h-screen overflow-hidden px-5 py-24 md:px-8 md:py-56">
      <PhilosophyBackground refProp={parallaxRef} />
      <div className="relative z-10">
        <div className="mb-12 font-mono-ui text-[9px] uppercase tracking-[.3em] text-white/60">01 / Philosophy</div>
        <div className="max-w-6xl text-[11vw] leading-[.86] tracking-[-.065em] text-white md:text-[8.7vw]">
          {philosophyLines.map((line, i) => (
            <div key={line} className={`ph-line ${i === 2 ? 'font-serif-display italic' : ''}`}>
              {line}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
