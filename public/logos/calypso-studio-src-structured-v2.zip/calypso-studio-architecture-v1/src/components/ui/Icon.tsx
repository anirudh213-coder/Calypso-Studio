interface IconProps {
  className?: string;
}

export const ArrowIcon = ({ className = 'h-5 w-5' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path d="M5 19L19 5M8 5H19V16" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const MailIcon = ({ className = 'h-6 w-6' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect x="3" y="5" width="18" height="14" rx="1" stroke="currentColor" strokeWidth="1.2" />
    <path d="M4 7L12 13L20 7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const PhoneIcon = ({ className = 'h-6 w-6' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path d="M7.2 3.8L10 8L8.3 10.1C9.4 12.4 11.2 14.2 13.5 15.3L15.6 13.6L19.8 16.4C20.5 16.9 20.7 17.9 20.2 18.6L18.9 20.3C18.4 21 17.5 21.2 16.7 20.9C10 18.6 5.4 14 3.1 7.3C2.8 6.5 3 5.6 3.7 5.1L5.4 3.8C6.1 3.3 6.7 3.1 7.2 3.8Z" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const LocationIcon = ({ className = 'h-6 w-6' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <path d="M19 10C19 15 12 21 12 21C12 21 5 15 5 10C5 6.13 8.13 3 12 3C15.87 3 19 6.13 19 10Z" stroke="currentColor" strokeWidth="1.2" />
    <circle cx="12" cy="10" r="2.5" stroke="currentColor" strokeWidth="1.2" />
  </svg>
);

export const InstagramIcon = ({ className = 'h-6 w-6' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" stroke="currentColor" strokeWidth="1.2" />
    <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.2" />
    <circle cx="17.5" cy="6.5" r="1" fill="currentColor" />
  </svg>
);

export const LinkedinIcon = ({ className = 'h-6 w-6' }: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">
    <rect x="3.5" y="3.5" width="17" height="17" stroke="currentColor" strokeWidth="1.2" />
    <path d="M7 10V17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    <circle cx="7" cy="7" r="0.9" fill="currentColor" />
    <path d="M11 17V13.5C11 11.8 11.8 10.8 13.2 10.8C14.8 10.8 15.5 12 15.5 13.5V17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
  </svg>
);
