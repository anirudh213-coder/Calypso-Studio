export const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'philosophy', label: 'Philosophy' },
  { id: 'archive', label: 'Archive' },
  { id: 'connect', label: 'Connect' },
] as const;

export const projects = [
  {
    year: '2026',
    title: 'Forma',
    category: 'Digital Design',
    video: '/videos/design.mp4',
  },
  {
    year: '2025',
    title: 'Noma House',
    category: 'Interior Design',
    video: '/videos/house.mp4',
  },
  {
    year: '2025',
    title: 'Objects No. 01',
    category: 'Art Direction',
    video: '/videos/sculpture.mp4',
  },
];

export const philosophyLines = [
  'We make digital spaces',
  'that feel less like interfaces',
  'and more like places.',
];

export const services = [
  'DIGITAL DESIGN',
  'INTERIOR DESIGN',
  'ART DIRECTION',
  'IDENTITY',
  'SPATIAL',
  'WEB EXPERIENCES',
];

export const references = [
  { name: 'EK Type', src: '/logos/Ek-logo.svg' },
  { name: 'OBYS', src: '/logos/obys.svg' },
  { name: 'Pentagram', src: '/logos/Pentagram_(design_firm)_logo.svg' },
  { name: 'Adobe', src: '/logos/adobe.svg' },
  { name: 'alienware', src: '/logos/alienware.svg' },
  { name: 'airbnb-wordmark', src: '/logos/airbnb-wordmark.svg' },
  { name: 'spotify-wordmark', src: '/logos/spotify-wordmark.svg' },
  { name: 'asus', src: '/logos/asus.svg' },
  { name: 'airtel', src: '/logos/airtel.svg' },
  { name: 'airasia', src: '/logos/airasia.svg' },
  { name: 'air-canada', src: '/logos/air-canada.svg' },
  { name: 'Awwwards', src: '/logos/awwwards-mono.svg' },
  { name: 'CSS Design Awards', src: '/logos/cssda-wotd-white.svg' },
  { name: 'The One Club', src: '/logos/ONE_Asia_Logo.png' },
  { name: 'bbc', src: '/logos/bbc.svg' },
  { name: 'alibaba', src: '/logos/alibaba.svg' },
];

export const philosophyImages = [
  'https://images.unsplash.com/photo-1728555729413-06b511297f64?auto=format&fit=crop&w=1800&q=85',
  'https://images.unsplash.com/photo-1504293538349-0be9a181d474?auto=format&fit=crop&w=1800&q=85',
  'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1800&q=85',
];

export const subtitleLines = [
  'INDEPENDENT DIGITAL DESIGN STUDIO /',
  'INDIA — WORLDWIDE',
];

export const heroLetters = [
  { char: 'C', from: { x: 100, y: 0 } },
  { char: 'A', from: { x: 0, y: -100 } },
  { char: 'L', from: { x: -100, y: 0 } },
  { char: 'Y', from: { x: 0, y: 100 } },
  { char: 'P', from: { x: 200, y: 0 } },
  { char: 'S', from: { x: 200, y: 0 } },
  { char: 'O', from: { x: 200, y: 0 } },
] as const;

export type UnicodeRange = {
  start: number;
  end: number;
  name: string;
};

export const unicodeRanges: UnicodeRange[] = [
  { name: 'Devanagari', start: 0x0904, end: 0x097f },
  { name: 'Bengali', start: 0x0981, end: 0x09ff },
  { name: 'Tamil', start: 0x0b82, end: 0x0bff },
  { name: 'Telugu', start: 0x0c00, end: 0x0c7f },
  { name: 'Kannada', start: 0x0c80, end: 0x0cff },
  { name: 'Malayalam', start: 0x0d00, end: 0x0d7f },
  { name: 'Thai', start: 0x0e01, end: 0x0e7f },
  { name: 'Lao', start: 0x0e81, end: 0x0eff },
  { name: 'Myanmar', start: 0x1000, end: 0x109f },
  { name: 'Khmer', start: 0x1780, end: 0x17ff },
  { name: 'Hebrew', start: 0x0590, end: 0x05ff },
  { name: 'Arabic', start: 0x0600, end: 0x06ff },
  { name: 'Greek', start: 0x0370, end: 0x03ff },
  { name: 'Cyrillic', start: 0x0400, end: 0x04ff },
  { name: 'Armenian', start: 0x0531, end: 0x058f },
  { name: 'Georgian', start: 0x10a0, end: 0x10ff },
  { name: 'Ethiopic', start: 0x1200, end: 0x137f },
  { name: 'Hiragana', start: 0x3041, end: 0x309f },
  { name: 'Katakana', start: 0x30a1, end: 0x30ff },
  { name: 'Han', start: 0x4e00, end: 0x9fff },
  { name: 'Hangul', start: 0xac00, end: 0xd7af },
];
